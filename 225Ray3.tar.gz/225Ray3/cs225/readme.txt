All files in the cs225 folder were taken from lab_intro of cs225.
Uses lodepng to create classes for PNGs and HSLAPixels both of which
are used heavily in my project.
